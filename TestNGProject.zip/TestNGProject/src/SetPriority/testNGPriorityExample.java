package SetPriority;
import org.testng.annotations.Test;

public class testNGPriorityExample {
@Test(priority = 1) 
public void one() 
{ 
  System.out.println("First Test Case"); 
} 
@Test(priority = 2) 
public void two()
{ 
  System.out.println("Second Test Case");
} 
@Test(priority = 3) 
public void three()
{ 
  System.out.println("Third Test Case"); 
} 

}