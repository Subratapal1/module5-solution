package withoutPriority;

import org.testng.annotations.Test;

public class NoPriority_Example {
@Test 
public void one() 
{ 
  System.out.println("First Test Case"); 
} 
@Test 
public void two()
{ 
  System.out.println("Second Test Case"); 
} 
@Test 
public void three()
{ 
  System.out.println("Third Test Case"); 
} 


}